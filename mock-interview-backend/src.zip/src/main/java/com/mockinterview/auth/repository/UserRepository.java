package com.mockinterview.auth.repository;

import com.mockinterview.auth.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByEmail(String email);
    long countByRole_Name(String roleName);

    boolean existsByEmail(String email);
    boolean existsByRole_Name(String roleName);
}